function Game() {
  if(!(this instanceof arguments.callee)) {
    return new arguments.callee(arguments)
  }
  var a = this;
  a.gameLoop = null;
  a.init = function() {
    a.canvas = $("#game").get(0);
    a.context = $("#game").get(0).getContext("2d");
    a.sequence = null;
    a.position = 0;
    a.currentRound = 1;
    a.playersTurn = !1;
    a.playerSequence = [];
    a.generateSequence(3);
    a.setupTimelines();
    a.setupAudioChannels();
    a.canvas.addEventListener("click", a.handleMouseClick, !1);
    a.startGame()
  };
  a.setupTimelines = function() {
    a.redColor = "rgb(200,0,0)";
    a.greenColor = "rgb(0,150,0)";
    a.blueColor = "rgb(0,0,150)";
    a.yellowColor = "rgb(150,150,0)";
    a.timelines = {};
    var b = new Timeline(this);
    b.addPropertiesToInterpolate([{property:"redColor", goingThrough:{0:"rgb(200,0,0)", "0.5":"rgb(255,0,0)", 1:"rgb(200,0,0)"}, interpolator:new RGBPropertyInterpolator}]);
    var c = new Timeline(this);
    c.addPropertiesToInterpolate([{property:"greenColor", goingThrough:{0:"rgb(0,150,0)", "0.5":"rgb(0,255,0)", 1:"rgb(0,150,0)"}, interpolator:new RGBPropertyInterpolator}]);
    var d = new Timeline(this);
    d.addPropertiesToInterpolate([{property:"blueColor", goingThrough:{0:"rgb(0,0,150)", "0.5":"rgb(0,0,255)", 1:"rgb(0,0,150)"}, interpolator:new RGBPropertyInterpolator}]);
    var f = new Timeline(this);
    f.addPropertiesToInterpolate([{property:"yellowColor", goingThrough:{0:"rgb(150,150,0)", "0.5":"rgb(255,255,0)", 1:"rgb(150,150,0)"}, interpolator:new RGBPropertyInterpolator}]);
    b.duration = c.duration = d.duration = f.duration = 500;
    a.timelines.red = b;
    a.timelines.blue = d;
    a.timelines.green = c;
    a.timelines.yellow = f
  };
  a.setupAudioChannels = function() {
    a.numChannels = 1;
    a.channels = [];
    for(var b = 0;b < a.numChannels;b++) {
      a.channels[b] = new Audio
    }
    a.sounds = {};
    a.sounds.red = "sounds/A2h.mp3";
    a.sounds.green = "sounds/A3h.mp3";
    a.sounds.blue = "sounds/D3h.mp3";
    a.sounds.yellow = "sounds/G3h.mp3"
  };
  a.startGame = function() {
    a.gameLoop = new Timeline(this);
    a.gameLoop.addEventListener("onpulse", function() {
      if(!a.playersTurn) {
        a.playersTurn = !0, a.playSequence()
      }
      a.drawSquares()
    });
    a.gameLoop.playInfiniteLoop()
  };
  a.generateSequence = function(b) {
    if(a.sequence == null) {
      a.sequence = []
    }
    for(var c = 0;c < b;c++) {
      a.sequence.push(Math.floor(Math.random() * 100) % 4)
    }
  };
  a.playSequence = function() {
    a.currentPosition = 1;
    a.audios = [];
    for(var b = 0;b < a.sequence.length;b++) {
      switch(a.sequence[b]) {
        case 0:
          a.audios.push({audio:new Audio(a.sounds.red), timeline:a.timelines.red});
          break;
        case 1:
          a.audios.push({audio:new Audio(a.sounds.green), timeline:a.timelines.green});
          break;
        case 2:
          a.audios.push({audio:new Audio(a.sounds.blue), timeline:a.timelines.blue});
          break;
        case 3:
          a.audios.push({audio:new Audio(a.sounds.yellow), timeline:a.timelines.yellow})
      }
      b < a.sequence.length - 1 && a.audios[b].audio.addEventListener("ended", a.playNext, !1)
    }
    a.audios[0].audio.play();
    a.audios[0].timeline.play()
  };
  a.playNext = function() {
    var b = a.currentPosition++;
    a.audios[b].audio.play();
    a.audios[b].timeline.play()
  };
  a.drawGameText = function() {
    var b = a.context;
    b.font = "36px ReenieBeanie, serif";
    b.fillText("Copy Me", 250, 250);
    b.fillText("Round " + a.currentRound, 250, 300)
  };
  a.drawSquares = function() {
    var b = a.context;
    b.clearRect(0, 0, 600, 600);
    a.drawGameText();
    b.shadowColor = "gray";
    b.save();
    b.fillStyle = a.redColor;
    b.shadowOffsetX = 5;
    b.shadowOffsetY = 10;
    b.beginPath();
    b.rect(200, 0, 200, 200);
    b.fill();
    b.restore();
    b.save();
    b.fillStyle = a.blueColor;
    b.shadowOffsetX = 5;
    b.shadowOffsetY = 10;
    b.beginPath();
    b.rect(0, 200, 200, 200);
    b.fill();
    b.restore();
    b.save();
    b.fillStyle = a.yellowColor;
    b.shadowOffsetX = 5;
    b.shadowOffsetY = 10;
    b.beginPath();
    b.rect(400, 200, 200, 200);
    b.fill();
    b.restore();
    b.save();
    b.fillStyle = a.greenColor;
    b.shadowOffsetX = 5;
    b.shadowOffsetY = 10;
    b.beginPath();
    b.rect(200, 400, 200, 200);
    b.fill();
    b.restore()
  };
  a.handleMouseClick = function(b) {
    x = b.clientX - a.canvas.offsetLeft;
    y = b.clientY - a.canvas.offsetTop;
    console.log("x,y:" + x + "," + y);
    var c;
    x >= 200 && x <= 400 ? y >= 0 && y <= 200 ? (b = new Audio(a.sounds.red), b.play(), a.timelines.red.play(), c = 0) : y >= 400 && y <= 600 && (b = new Audio(a.sounds.green), b.play(), a.timelines.green.play(), c = 1) : y >= 200 && y <= 400 && (x >= 0 && x <= 200 ? (b = new Audio(a.sounds.blue), b.play(), a.timelines.blue.play(), c = 2) : x >= 400 && x <= 600 && (b = new Audio(a.sounds.yellow), b.play(), a.timelines.yellow.play(), c = 3));
    console.log("value:" + c);
    if(c != void 0) {
      a.playerSequence.push(c), a.playerSequence[a.position] != a.sequence[a.position] ? (a.timelines.red.play(), a.timelines.green.play(), a.timelines.blue.play(), a.timelines.yellow.play(), a.currentRound = 1, a.position = 0, a.playerSequence = [], a.sequence = a.generateSequence(3), a.playersTurn = !1) : a.playerSequence.length == a.sequence.length ? (a.currentRound++, a.playerSequence = [], a.position = 0, a.generateSequence(1), a.playersTurn = !1) : a.position++, console.log(a.sequence), console.log(a.playerSequence)
    }
  };
  a.init()
}
;var Zepto = function() {
  function a(a) {
    return a.filter(function(a) {
      return a !== k && a !== null
    })
  }
  function b(a) {
    return a.replace(/-+(.)?/g, function(a, b) {
      return b ? b.toUpperCase() : ""
    })
  }
  function c(a, b) {
    this.dom = a || [];
    this.selector = b || ""
  }
  function d(b, g) {
    if(b == l) {
      return new c
    }else {
      if(g !== k) {
        return d(g).find(b)
      }else {
        if(typeof b === "function") {
          return d(l).ready(b)
        }else {
          var h;
          b instanceof c ? h = b.dom : b instanceof Array ? h = b : b instanceof Element || b === window ? h = [b] : j.test(b) ? (i.innerHTML = ("" + b).trim(), h = f.call(i.childNodes), i.innerHTML = "") : h = e(l, b);
          return new c(a(h), b)
        }
      }
    }
  }
  var f = [].slice, g, h, e, j, i, l = window.document, k;
  if(String.prototype.trim === k) {
    String.prototype.trim = function() {
      return this.replace(/^\s+/, "").replace(/\s+$/, "")
    }
  }
  j = /^\s*<.+>/;
  i = l.createElement("div");
  d.extend = function(a, b) {
    for(g in b) {
      a[g] = b[g]
    }
    return a
  };
  d.qsa = e = function(a, b) {
    return f.call(a.querySelectorAll(b))
  };
  d.fn = {ready:function(a) {
    l.addEventListener("DOMContentLoaded", a, !1);
    return this
  }, compact:function() {
    this.dom = a(this.dom);
    return this
  }, get:function(a) {
    return a === k ? this.dom : this.dom[a]
  }, remove:function() {
    return this.each(function(a) {
      a.parentNode.removeChild(a)
    })
  }, each:function(a) {
    this.dom.forEach(a);
    return this
  }, filter:function(a) {
    return d(this.dom.filter(function(b) {
      return e(b.parentNode, a).indexOf(b) >= 0
    }))
  }, is:function(a) {
    return this.dom.length > 0 && d(this.dom[0]).filter(a).dom.length > 0
  }, first:function() {
    this.dom = a([this.dom[0]]);
    return this
  }, last:function() {
    this.dom = a([this.dom[this.dom.length - 1]]);
    return this
  }, find:function(a) {
    return d(this.dom.map(function(b) {
      return e(b, a)
    }).reduce(function(a, b) {
      return a.concat(b)
    }, []))
  }, closest:function(a) {
    for(var b = this.dom[0].parentNode, a = e(l, a);b && a.indexOf(b) < 0;) {
      b = b.parentNode
    }
    return d(b && b !== l ? b : [])
  }, pluck:function(a) {
    return this.dom.map(function(b) {
      return b[a]
    })
  }, show:function() {
    return this.css("display", "block")
  }, hide:function() {
    return this.css("display", "none")
  }, prev:function() {
    return d(this.pluck("previousElementSibling"))
  }, next:function() {
    return d(this.pluck("nextElementSibling"))
  }, html:function(a) {
    return a === k ? this.dom.length > 0 ? this.dom[0].innerHTML : null : this.each(function(b) {
      b.innerHTML = a
    })
  }, text:function(a) {
    return a === k ? this.dom.length > 0 ? this.dom[0].innerText : null : this.each(function(b) {
      b.innerText = a
    })
  }, attr:function(a, b) {
    return typeof a == "string" && b === k ? this.dom.length > 0 && this.dom[0].nodeName === "INPUT" && this.dom[0].type === "text" && a === "value" ? this.dom[0].value : this.dom.length > 0 ? this.dom[0].getAttribute(a) || k : null : this.each(function(d) {
      if(typeof a == "object") {
        for(g in a) {
          d.setAttribute(g, a[g])
        }
      }else {
        d.setAttribute(a, b)
      }
    })
  }, offset:function() {
    var a = this.dom[0].getBoundingClientRect();
    return{left:a.left + l.body.scrollLeft, top:a.top + l.body.scrollTop, width:a.width, height:a.height}
  }, css:function(a, d) {
    if(d === k && typeof a == "string") {
      return this.dom[0].style[b(a)]
    }
    h = "";
    for(g in a) {
      h += g + ":" + a[g] + ";"
    }
    typeof a == "string" && (h = a + ":" + d);
    return this.each(function(a) {
      a.style.cssText += ";" + h
    })
  }, index:function(a) {
    return this.dom.indexOf(d(a).get(0))
  }, hasClass:function(a) {
    return RegExp("(^|\\s)" + a + "(\\s|$)").test(this.dom[0].className)
  }, addClass:function(a) {
    return this.each(function(b) {
      !d(b).hasClass(a) && (b.className += (b.className ? " " : "") + a)
    })
  }, removeClass:function(a) {
    return this.each(function(b) {
      b.className = b.className.replace(RegExp("(^|\\s)" + a + "(\\s|$)"), " ").trim()
    })
  }, toggleClass:function(a, b) {
    return this.each(function(c) {
      b !== k && !b || d(c).hasClass(a) ? d(c).removeClass(a) : d(c).addClass(a)
    })
  }};
  ["width", "height"].forEach(function(a) {
    d.fn[a] = function() {
      return this.offset()[a]
    }
  });
  var m = {append:"beforeEnd", prepend:"afterBegin", before:"beforeBegin", after:"afterEnd"};
  for(g in m) {
    d.fn[g] = function(a) {
      return function(b) {
        return this.each(function(d) {
          d["insertAdjacent" + (b instanceof Element ? "Element" : "HTML")](a, b)
        })
      }
    }(m[g])
  }
  c.prototype = d.fn;
  return d
}();
"$" in window || (window.$ = Zepto);
(function(a) {
  function b(a, b, d, f) {
    b = c(b);
    if(b.ns) {
      var g = RegExp("(?:^| )" + b.ns.replace(" ", " .* ?") + "(?: |$)")
    }
    return(e[a._zid || (a._zid = j++)] || []).filter(function(a) {
      return a && (!b.e || a.e == b.e) && (!b.ns || g.test(a.ns)) && (!d || a.fn == d) && (!f || a.sel == f)
    })
  }
  function c(a) {
    a = ("" + a).split(".");
    return{e:a[0], ns:a.slice(1).sort().join(" ")}
  }
  function d(b, d, f, g, h) {
    var i = b._zid || (b._zid = j++), o = e[i] || (e[i] = []);
    d.split(/\s/).forEach(function(d) {
      d = a.extend(c(d), {fn:f, sel:g, del:h, i:o.length});
      o.push(d);
      b.addEventListener(d.e, h || f, !1)
    })
  }
  function f(a, d, c, f) {
    var g = a._zid || (a._zid = j++);
    (d || "").split(/\s/).forEach(function(d) {
      b(a, d, c, f).forEach(function(b) {
        delete e[g][b.i];
        a.removeEventListener(b.e, b.del || b.fn, !1)
      })
    })
  }
  function g(b) {
    var d = a.extend({originalEvent:b}, b);
    i.forEach(function(a) {
      d[a] = function() {
        return b[a].apply(b, arguments)
      }
    });
    return d
  }
  var h = a.qsa, e = {}, j = 1;
  a.event = {add:function(a, b, c) {
    d(a, b, c)
  }, remove:function(a, b, d) {
    f(a, b, d)
  }};
  a.fn.bind = function(a, b) {
    return this.each(function(c) {
      d(c, a, b)
    })
  };
  a.fn.unbind = function(a, b) {
    return this.each(function(d) {
      f(d, a, b)
    })
  };
  var i = ["preventDefault", "stopImmediatePropagation", "stopPropagation"];
  a.fn.delegate = function(b, c, f) {
    return this.each(function(e) {
      d(e, c, f, b, function(d) {
        for(var c = d.target, i = h(e, b);c && i.indexOf(c) < 0;) {
          c = c.parentNode
        }
        c && c !== e && c !== document && f.call(c, a.extend(g(d), {currentTarget:c, liveFired:e}))
      })
    })
  };
  a.fn.undelegate = function(a, b, d) {
    return this.each(function(c) {
      f(c, b, d, a)
    })
  };
  a.fn.live = function(b, d) {
    a(document.body).delegate(this.selector, b, d);
    return this
  };
  a.fn.die = function(b, d) {
    a(document.body).undelegate(this.selector, b, d);
    return this
  };
  a.fn.trigger = function(a) {
    return this.each(function(b) {
      var d = document.createEvent("Events");
      b.dispatchEvent(d, d.initEvent(a, !0, !1))
    })
  }
})(Zepto);
(function(a) {
  function b(a) {
    var b = {}, c = a.match(/(Android)\s+([\d.]+)/), h = a.match(/(iPhone\sOS)\s([\d_]+)/), e = a.match(/(iPad).*OS\s([\d_]+)/), a = a.match(/(webOS)\/([\d.]+)/);
    if(c) {
      b.android = !0, b.version = c[2]
    }
    if(h) {
      b.ios = !0, b.version = h[2].replace(/_/g, "."), b.iphone = !0
    }
    if(e) {
      b.ios = !0, b.version = e[2].replace(/_/g, "."), b.ipad = !0
    }
    if(a) {
      b.webos = !0, b.version = a[2]
    }
    return b
  }
  a.os = b(navigator.userAgent);
  a.__detect = b;
  var c = navigator.userAgent.match(/WebKit\/([\d.]+)/);
  a.browser = c ? {webkit:!0, version:c[1]} : {webkit:!1}
})(Zepto);
(function(a) {
  a.fn.anim = function(a, c, d) {
    var f = [], g, h;
    for(h in a) {
      h === "opacity" ? g = a[h] : f.push(h + "(" + a[h] + ")")
    }
    return this.css({"-webkit-transition":"all " + (c !== void 0 ? c : 0.5) + "s " + (d || ""), "-webkit-transform":f.join(" "), opacity:g})
  }
})(Zepto);
(function(a) {
  var b = {}, c;
  a(document).ready(function() {
    a(document.body).bind("touchstart", function(a) {
      var f = Date.now(), g = f - (b.last || f);
      b.target = "tagName" in a.touches[0].target ? a.touches[0].target : a.touches[0].target.parentNode;
      c && clearTimeout(c);
      b.x1 = a.touches[0].pageX;
      if(g > 0 && g <= 250) {
        b.isDoubleTap = !0
      }
      b.last = f
    }).bind("touchmove", function(a) {
      b.x2 = a.touches[0].pageX
    }).bind("touchend", function() {
      b.isDoubleTap ? (a(b.target).trigger("doubleTap"), b = {}) : b.x2 > 0 ? (Math.abs(b.x1 - b.x2) > 30 && a(b.target).trigger("swipe") && a(b.target).trigger("swipe" + (b.x1 - b.x2 > 0 ? "Left" : "Right")), b.x1 = b.x2 = b.last = 0) : "last" in b && (c = setTimeout(function() {
        c = null;
        a(b.target).trigger("tap");
        b = {}
      }, 250))
    }).bind("touchcancel", function() {
      b = {}
    })
  });
  ["swipe", "swipeLeft", "swipeRight", "doubleTap", "tap"].forEach(function(b) {
    a.fn[b] = function(a) {
      return this.bind(b, a)
    }
  })
})(Zepto);
(function(a) {
  function b() {
  }
  a.ajax = function(a) {
    var a = a || {}, f = a.data, g = a.success || b, h = a.error || b, e = c[a.dataType], j = a.contentType, i = new XMLHttpRequest;
    i.onreadystatechange = function() {
      if(i.readyState == 4) {
        if(i.status >= 200 && i.status < 300 || i.status == 0) {
          if(e == "application/json") {
            var a, b = !1;
            try {
              a = JSON.parse(i.responseText)
            }catch(c) {
              b = c
            }
            b ? h(i, "parsererror", b) : g(a, "success", i)
          }else {
            g(i.responseText, "success", i)
          }
        }else {
          h(i, "error")
        }
      }
    };
    i.open(a.type || "GET", a.url || window.location, !0);
    e && i.setRequestHeader("Accept", e);
    f instanceof Object && (f = JSON.stringify(f), j = j || "application/json");
    j && i.setRequestHeader("Content-Type", j);
    i.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    i.send(f)
  };
  var c = a.ajax.mimeTypes = {json:"application/json", xml:"application/xml", html:"text/html", text:"text/plain"};
  a.get = function(b, c) {
    a.ajax({url:b, success:c})
  };
  a.post = function(b, c, g, h) {
    c instanceof Function && (h = h || g, g = c, c = null);
    a.ajax({type:"POST", url:b, data:c, success:g, dataType:h})
  };
  a.getJSON = function(b, c) {
    a.ajax({url:b, success:c, dataType:"json"})
  };
  a.fn.load = function(b, c) {
    if(!this.dom.length) {
      return this
    }
    var g = this, h = b.split(/\s/), e;
    h.length > 1 && (b = h[0], e = h[1]);
    a.get(b, function(b) {
      g.html(e ? a(document.createElement("div")).html(b).find(e).html() : b);
      c && c()
    });
    return this
  }
})(Zepto);
(function(a) {
  var b = [], c;
  a.fn.remove = function() {
    return this.each(function(a) {
      if(a.tagName == "IMG") {
        b.push(a), a.src = "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=", c && clearTimeout(c), c = setTimeout(function() {
          b = []
        }, 6E4)
      }
      a.parentNode.removeChild(a)
    })
  }
})(Zepto);
var lastTime = (new Date).getTime(), timelineId = 0, timelineScenarioId = 0, TimelineState = {IDLE:"IDLE", READY:"READY", PLAYING_FORWARD:"PLAYING_FORWARD", PLAYING_REVERSE:"PLAYING_REVERSE", SUSPENDED:"SUSPENDED", CANCELLED:"CANCELLED", DONE:"DONE"}, TimelineScenarioState = {IDLE:"IDLE", PLAYING:"PLAYING", SUSPENDED:"SUSPENDED", DONE:"DONE"}, RepeatBehavior = {LOOP:"LOOP", REVERSE:"REVERSE"};
function RGBPropertyInterpolator() {
  var a = function(a, c, d) {
    a = parseInt(a);
    c = parseInt(c);
    return parseInt(parseFloat(a + d * (c - a)))
  };
  this.interpolate = function(b, c, d) {
    var b = b.substring(4, b.length - 1).split(","), f = c.substring(4, c.length - 1).split(","), c = a(b[0], f[0], d), g = a(b[1], f[1], d), d = a(b[2], f[2], d);
    return"rgb(" + c + "," + g + "," + d + ")"
  }
}
function IntPropertyInterpolator() {
  this.interpolate = function(a, b, c) {
    return parseInt(parseFloat(a + (b - a) * c))
  }
}
function FloatPropertyInterpolator() {
  this.interpolate = function(a, b, c) {
    a = parseFloat(a);
    b = parseFloat(b);
    return parseFloat(a + (b - a) * c)
  }
}
function LinearEase() {
  this.map = function(a) {
    return a
  }
}
function SineEase() {
  this.map = function(a) {
    return Math.sin(a * Math.PI / 2)
  }
}
function Point(a, b) {
  this.x = a;
  this.y = b
}
function LengthItem(a, b) {
  this.len = a;
  this.t = b;
  this.fraction = 0;
  this.setFraction = function(a) {
    this.fraction = this.len / a
  }
}
function SplineEase(a, b, c, d) {
  if(a < 0 || a > 1 || b < 0 || b > 1 || c < 0 || c > 1 || d < 0 || d > 1) {
    throw"Control points must be in the range [0, 1]";
  }
  this.x1 = a;
  this.x2 = c;
  this.y1 = b;
  this.y2 = d;
  this.lengths = [];
  this.__getXY = function(e) {
    var g = 1 - e, f = 3 * e * g * g;
    g *= 3 * e * e;
    e *= e * e;
    return new Point(f * a + g * c + e, f * b + g * d + e)
  };
  this.__getY = function(a) {
    var c = 1 - a;
    return 3 * a * c * c * b + 3 * a * a * c * d + a * a * a
  };
  this.map = function(a) {
    for(var b = 1, c = 0, d = 0, e = 0;e < this.lengths.length;++e) {
      var g = this.lengths[e], f = g.fraction, g = g.t;
      if(a <= f) {
        b = c + (a - d) / (f - d) * (g - c);
        break
      }
      d = f;
      c = g
    }
    return this.__getY(b)
  };
  for(var f = 0, g = 0, h = 0, e = 0.01;e <= 1;e += 0.01) {
    var j = this.__getXY(e);
    h += Math.sqrt((j.x - f) * (j.x - f) + (j.y - g) * (j.y - g));
    f = new LengthItem(h, e);
    this.lengths[this.lengths.length] = f;
    f = j.x;
    g = j.y
  }
  for(e = 0;e < this.lengths.length;++e) {
    f = this.lengths[e], f.setFraction(h)
  }
}
function QuadraticEaseIn() {
  this.map = function(a) {
    return a * a
  }
}
function QuadraticEaseOut() {
  this.map = function(a) {
    return-a * (a - 2)
  }
}
function QuadraticEaseInOut() {
  this.map = function(a) {
    if((a *= 2) < 1) {
      return 0.5 * a * a
    }
    return-0.5 * (--a * (a - 2) - 1)
  }
}
function CubicEaseIn() {
  this.map = function(a) {
    return a * a * a
  }
}
function CubicEaseOut() {
  this.map = function(a) {
    return--a * a * a + 1
  }
}
function CubicEaseInOut() {
  this.map = function(a) {
    if((a *= 2) < 1) {
      return 0.5 * a * a * a
    }
    return 0.5 * ((a -= 2) * a * a + 2)
  }
}
function QuarticEaseIn() {
  this.map = function(a) {
    return a * a * a * a
  }
}
function QuarticEaseOut() {
  this.map = function(a) {
    return-(--a * a * a * a - 1)
  }
}
function QuarticEaseInOut() {
  this.map = function(a) {
    if((a *= 2) < 1) {
      return 0.5 * a * a * a * a
    }
    return-0.5 * ((a -= 2) * a * a * a - 2)
  }
}
function SinusoidalEaseIn() {
  this.map = function(a) {
    return-Math.cos(a * Math.PI / 2) + 1
  }
}
function SinusoidalEaseOut() {
  this.map = function(a) {
    return Math.sin(a * Math.PI / 2)
  }
}
function SinusoidalEaseInOut() {
  this.map = function(a) {
    return-0.5 * (Math.cos(Math.PI * a) - 1)
  }
}
function ExponentialEaseIn() {
  this.map = function(a) {
    return a == 0 ? 0 : Math.pow(2, 10 * (a - 1))
  }
}
function ExponentialEaseOut() {
  this.map = function(a) {
    return a == 1 ? 1 : -Math.pow(2, -10 * a) + 1
  }
}
function ExponentialEaseInOut() {
  this.map = function(a) {
    if(a == 0) {
      return 0
    }
    if(a == 1) {
      return 1
    }
    if((a *= 2) < 1) {
      return 0.5 * Math.pow(2, 10 * (a - 1))
    }
    return 0.5 * (-Math.pow(2, -10 * (a - 1)) + 2)
  }
}
function CircularEaseIn() {
  this.map = function(a) {
    return-(Math.sqrt(1 - a * a) - 1)
  }
}
function CircularEaseOut() {
  this.map = function(a) {
    return Math.sqrt(1 - --a * a)
  }
}
function CircularEaseInOut() {
  this.map = function(a) {
    if((a /= 0.5) < 1) {
      return-0.5 * (Math.sqrt(1 - a * a) - 1)
    }
    return 0.5 * (Math.sqrt(1 - (a -= 2) * a) + 1)
  }
}
function ElasticEaseIn() {
  this.map = function(a) {
    var b, c = 0.1, d = 0.4;
    if(a == 0) {
      return 0
    }
    if(a == 1) {
      return 1
    }
    d || (d = 0.3);
    !c || c < 1 ? (c = 1, b = d / 4) : b = d / (2 * Math.PI) * Math.asin(1 / c);
    return-(c * Math.pow(2, 10 * (a -= 1)) * Math.sin((a - b) * 2 * Math.PI / d))
  }
}
function ElasticEaseOut() {
  this.map = function(a) {
    var b, c = 0.1, d = 0.4;
    if(a == 0) {
      return 0
    }
    if(a == 1) {
      return 1
    }
    d || (d = 0.3);
    !c || c < 1 ? (c = 1, b = d / 4) : b = d / (2 * Math.PI) * Math.asin(1 / c);
    return c * Math.pow(2, -10 * a) * Math.sin((a - b) * 2 * Math.PI / d) + 1
  }
}
function ElasticEaseInOut() {
  this.map = function(a) {
    var b, c = 0.1, d = 0.4;
    if(a == 0) {
      return 0
    }
    if(a == 1) {
      return 1
    }
    d || (d = 0.3);
    !c || c < 1 ? (c = 1, b = d / 4) : b = d / (2 * Math.PI) * Math.asin(1 / c);
    if((a *= 2) < 1) {
      return-0.5 * c * Math.pow(2, 10 * (a -= 1)) * Math.sin((a - b) * 2 * Math.PI / d)
    }
    return c * Math.pow(2, -10 * (a -= 1)) * Math.sin((a - b) * 2 * Math.PI / d) * 0.5 + 1
  }
}
function BackEaseIn() {
  this.map = function(a) {
    return a * a * (2.70158 * a - 1.70158)
  }
}
function BackEaseOut() {
  this.map = function(a) {
    return(a -= 1) * a * (2.70158 * a + 1.70158) + 1
  }
}
function BackEaseInOut() {
  this.map = function(a) {
    if((a *= 2) < 1) {
      return 0.5 * a * a * (3.5949095 * a - 2.5949095)
    }
    return 0.5 * ((a -= 2) * a * (3.5949095 * a + 2.5949095) + 2)
  }
}
function BounceEaseIn() {
  this.bo = new BounceEaseOut;
  this.map = function(a) {
    return 1 - this.bo.map(1 - a)
  }
}
function BounceEaseOut() {
  this.map = function(a) {
    return(a /= 1) < 1 / 2.75 ? 7.5625 * a * a : a < 2 / 2.75 ? 7.5625 * (a -= 1.5 / 2.75) * a + 0.75 : a < 2.5 / 2.75 ? 7.5625 * (a -= 2.25 / 2.75) * a + 0.9375 : 7.5625 * (a -= 2.625 / 2.75) * a + 0.984375
  }
}
function BounceEaseInOut() {
  this.bi = new BounceEaseIn;
  this.bo = new BounceEaseOut;
  this.map = function(a) {
    if(a < 0.5) {
      return this.bi.map(a * 2) * 0.5
    }
    return this.bo.map(a * 2 - 1) * 0.5 + 0.5
  }
}
function KeyEases(a, b) {
  this.eases = [];
  if(b == void 0 || b[0] == void 0) {
    for(var c = 0;c < a;++c) {
      this.eases[this.eases.length] = new LinearEase
    }
  }else {
    if(b.length < a) {
      for(c = 0;c < a;++c) {
        this.eases[this.eases.length] = b[0]
      }
    }else {
      for(c = 0;c < a;++c) {
        this.eases[this.eases.length] = b[c]
      }
    }
  }
  this.interpolate = function(a, b) {
    return this.eases[a].map(b)
  }
}
function KeyTimes(a) {
  this.times = [];
  if(a[0] != 0) {
    throw"First time value must be zero";
  }
  if(a[a.length - 1] != 1) {
    throw"Last time value must be one";
  }
  for(var b = 0, c = 0;c < a.length;c++) {
    var d = a[c];
    if(d < b) {
      throw"Time values must be in increasing order";
    }
    b = this.times[this.times.length] = d
  }
  this.getInterval = function(a) {
    for(var b = 0, c = 1;c < this.times.length;++c) {
      if(this.times[c] >= a) {
        break
      }
      b = c
    }
    return b
  };
  this.getTime = function(a) {
    return this.times[a]
  }
}
function KeyValues(a, b) {
  this.values = [];
  this.propertyInterpolator = a;
  if(b == void 0) {
    throw"params array cannot be null";
  }else {
    if(b.length == 0) {
      throw"params array must have at least one element";
    }
  }
  b.length == 1 && (this.values[this.values.length] = void 0);
  for(var c = 0;c < b.length;c++) {
    this.values[this.values.length] = b[c]
  }
  this.getSize = function() {
    return values.length
  };
  this.setStartValue = function(a) {
    if(this.isToAnimation()) {
      this.startValue = a
    }
  };
  this.isToAnimation = function() {
    return values.get(0) == void 0
  };
  this.getValue = function(a, b, c) {
    var h = this.values[a];
    h == void 0 && (h = startValue);
    return a == b ? h : this.propertyInterpolator.interpolate(h, this.values[b], c)
  }
}
function KeyFrames(a, b, c) {
  this.__init = function(a, b, c) {
    var h = [], e = [], j;
    for(j in a) {
      e[e.length] = j
    }
    e.sort();
    for(j = 0;j < e.length;j++) {
      h[h.length] = a[e[j]]
    }
    a = h.length;
    this.keyTimes = new KeyTimes(e);
    this.keyValues = new KeyValues(b, h);
    this.eases = new KeyEases(a - 1, c)
  };
  this.getKeyValues = function() {
    return this.keyValues
  };
  this.getKeyTimes = function() {
    return this.keyTimes
  };
  this.getInterval = function(a) {
    return this.keyTimes.getInterval(a)
  };
  this.getValue = function(a) {
    var b = this.getInterval(a), c = this.keyTimes.getTime(b), h = this.keyTimes.getTime(b + 1), a = this.eases.interpolate(b, (a - c) / (h - c));
    a < 0 ? a = 0 : a > 1 && (a = 1);
    return this.keyValues.getValue(b, b + 1, a)
  };
  this.__init(a, b, [c])
}
function PropertyInfo(a, b, c, d, f) {
  this.mainObject = a;
  this.field = b;
  this.from = c;
  this.to = d;
  this.interpolator = f;
  this.updateValue = function(a) {
    this.mainObject[b] = f.interpolate(c, d, a)
  }
}
function KeyFramesPropertyInfo(a, b, c, d) {
  this.mainObject = a;
  this.field = b;
  this.keyFrames = new KeyFrames(c, d);
  this.updateValue = function(a) {
    a = this.keyFrames.getValue(a);
    this.mainObject[b] = a
  }
}
function EventHandler(a, b) {
  this.eventName = a;
  this.handler = b
}
function Stack() {
  var a = [], b = 0;
  this.empty = function() {
    return b == 0
  };
  this.peek = function() {
    return a[b - 1]
  };
  this.pop = function() {
    var c = this.peek();
    b--;
    delete a[b];
    return c
  };
  this.push = function(c) {
    a[b] = c;
    b++
  }
}
function Timeline(a) {
  this.durationFraction = 0;
  this.duration = 500;
  this.initialDelay = this.timeUntilPlay = 0;
  this.isLooping = !1;
  this.timelinePosition = 0;
  this.toCancelAtCycleBreak = !1;
  this.ease = new LinearEase;
  this.cycleDelay = 0;
  this.repeatCount = -1;
  this.doneCount = 0;
  var b = [], c = [], d = new Stack, f = timelineId++;
  d.push(TimelineState.IDLE);
  this.getMainObject = function() {
    return a
  };
  this.addPropertyToInterpolate = function(a, b, d, f) {
    a = new PropertyInfo(this.getMainObject(), a, b, d, f);
    c[c.length] = a
  };
  this.addPropertiesToInterpolate = function(a) {
    for(var b = 0;b < a.length;b++) {
      var d = a[b], f = d.property, i = d.interpolator, l = d.on;
      l == void 0 && (l = this.getMainObject());
      var k = d.goingThrough, d = k != void 0 ? new KeyFramesPropertyInfo(l, f, k, i) : new PropertyInfo(l, f, d.from, d.to, i), f = c;
      f[f.length] = d
    }
  };
  this.addEventListener = function(a, c) {
    var d = new EventHandler(a, c);
    b[b.length] = d
  };
  this.getState = function() {
    return d.peek()
  };
  this.__popState = function() {
    return d.pop()
  };
  this.__pushState = function(a) {
    a == TimelineState.DONE && this.doneCount++;
    d.push(a)
  };
  this.__replaceState = function(a) {
    d.pop();
    this.__pushState(a)
  };
  this.isDone = function() {
    return this.doneCount > 0
  };
  this.supportsReplay = function() {
    return!0
  };
  this.resetDoneFlag = function() {
    this.doneCount = 0
  };
  this.__play = function(a, b) {
    if(runningTimelines[f] == void 0) {
      var c = this.getState();
      this.timeUntilPlay = this.initialDelay - b;
      this.timeUntilPlay < 0 ? (this.durationFraction = -this.timeUntilPlay / this.duration, this.timelinePosition = this.ease.map(this.durationFraction), this.timeUntilPlay = 0) : this.timelinePosition = this.durationFraction = 0;
      this.__pushState(TimelineState.PLAYING_FORWARD);
      this.__pushState(TimelineState.READY);
      runningTimelines[f] = this;
      this.__callbackCallTimelineStateChanged(c)
    }else {
      if(c = this.getState(), c == TimelineState.READY ? (this.__popState(), this.__replaceState(TimelineState.PLAYING_FORWARD), this.__pushState(TimelineState.READY)) : (this.__replaceState(TimelineState.PLAYING_FORWARD), c != this.getState() && this.__callbackCallTimelineStateChanged(c)), a) {
        this.timelinePosition = this.durationFraction = 0, this.__callbackCallTimelinePulse()
      }
    }
  };
  this.play = function() {
    this.playSkipping(!1, 0)
  };
  this.playSkipping = function(a) {
    if(this.initialDelay + this.duration < a) {
      throw new IllegalArgumentException("Required skip longer than initial delay + duration");
    }
    this.isLooping = !1;
    this.__play(!1, a)
  };
  this.replay = function() {
    this.isLooping = !1;
    this.__play(!0, 0)
  };
  this.__playReverse = function(a, b) {
    if(runningTimelines[f] == void 0) {
      var c = this.getState();
      this.timeUntilPlay = this.initialDelay - b;
      this.timeUntilPlay < 0 ? (this.durationFraction = 1 + this.timeUntilPlay / this.duration, this.timelinePosition = this.ease.map(this.durationFraction), this.timeUntilPlay = 0) : this.timelinePosition = this.durationFraction = 1;
      this.__pushState(TimelineState.PLAYING_REVERSE);
      this.__pushState(TimelineState.READY);
      runningTimelines[f] = this;
      this.__callbackCallTimelineStateChanged(c)
    }else {
      if(c = this.getState(), c == TimelineState.READY ? (this.__popState(), this.__replaceState(TimelineState.PLAYING_REVERSE), this.__pushState(TimelineState.READY)) : (this.__replaceState(TimelineState.PLAYING_REVERSE), c != this.getState() && this.__callbackCallTimelineStateChanged(c)), a) {
        this.timelinePosition = this.durationFraction = 1, this.__callbackCallTimelinePulse()
      }
    }
  };
  this.playReverse = function() {
    this.playReverseSkipping(!1, 0)
  };
  this.playReverseSkipping = function(a) {
    if(this.initialDelay + this.duration < a) {
      throw"Required skip longer than initial delay + duration";
    }
    this.isLooping = !1;
    this.__playReverse(!1, a)
  };
  this.replayReverse = function() {
    this.isLooping = !1;
    this.__playReverse(!0, 0)
  };
  this.__playLoop = function(a) {
    if(runningTimelines[f] == void 0) {
      var b = this.getState();
      this.timeUntilPlay = this.initialDelay - a;
      this.timeUntilPlay < 0 ? (this.durationFraction = -this.timeUntilPlay / this.duration, this.timelinePosition = this.ease.map(this.durationFraction), this.timeUntilPlay = 0) : this.timelinePosition = this.durationFraction = 0;
      this.__pushState(TimelineState.PLAYING_FORWARD);
      this.__pushState(TimelineState.READY);
      this.toCancelAtCycleBreak = !1;
      runningTimelines[f] = this;
      this.__callbackCallTimelineStateChanged(b)
    }else {
      this.toCancelAtCycleBreak = !1
    }
  };
  this.playLoopSkipping = function(a, b, c) {
    if(this.initialDelay + this.duration < c) {
      throw"Required skip longer than initial delay + duration";
    }
    this.isLooping = !0;
    this.repeatCount = a;
    this.repeatBehavior = b;
    this.__playLoop(c)
  };
  this.playInfiniteLoop = function(a) {
    this.playLoop(-1, a)
  };
  this.playInfiniteLoopSkipping = function(a, b) {
    this.playLoopSkipping(-1, a, b)
  };
  this.playLoop = function(a, b) {
    this.playLoopSkipping(a, b, 0)
  };
  this.cancelAtCycleBreak = function() {
    this.toCancelAtCycleBreak = !0
  };
  this.cancel = function() {
    if(runningTimelines[f] != void 0) {
      delete runningTimelines[f];
      for(var a = this.getState();this.getState() != TimelineState.IDLE;) {
        this.__popState()
      }
      this.__pushState(TimelineState.CANCELLED);
      this.__callbackCallTimelineStateChanged(a);
      this.__popState();
      this.__callbackCallTimelineStateChanged(TimelineState.CANCELLED)
    }
  };
  this.end = function() {
    if(runningTimelines[f] != void 0) {
      delete runningTimelines[f];
      for(var a = timeline.getState(), b = timeline.durationFraction;this.getState() != TimelineState.IDLE;) {
        var c = this.__popState();
        c == TimelineState.PLAYING_FORWARD && (b = 1);
        c == TimelineState.PLAYING_REVERSE && (b = 0)
      }
      this.timelinePosition = this.durationFraction = b;
      this.__callbackCallTimelinePulse();
      this.__pushState(TimelineState.DONE);
      this.__callbackCallTimelineStateChanged(a);
      this.__popState();
      this.__callbackCallTimelineStateChanged(TimelineState.DONE)
    }
  };
  this.abort = function() {
    if(runningTimelines[f] != void 0) {
      for(delete runningTimelines[f];this.getState() != TimelineState.IDLE;) {
        this.__popState()
      }
    }
  };
  this.suspend = function() {
    if(runningTimelines[f] != void 0) {
      var a = this.getState();
      a != TimelineState.PLAYING_FORWARD && a != TimelineState.PLAYING_REVERSE && a != TimelineState.READY || (this.__pushState(TimelineState.SUSPENDED), this.__callbackCallTimelineStateChanged(a))
    }
  };
  this.resume = function() {
    if(runningTimelines[f] != void 0) {
      var a = this.getState();
      a == TimelineState.SUSPENDED && (this.__popState(), this.__callbackCallTimelineStateChanged(a))
    }
  };
  this.__callbackCallTimelinePulse = function() {
    this.timelinePosition = this.ease.map(this.durationFraction);
    for(var a = 0;a < b.length;a++) {
      var d = b[a];
      d.eventName == "onpulse" && d.handler(this, this.durationFraction, this.timelinePosition)
    }
    for(a = 0;a < c.length;a++) {
      c[a].updateValue(this.timelinePosition)
    }
  };
  this.__callbackCallTimelineStateChanged = function(a) {
    this.getState();
    this.timelinePosition = this.ease.map(this.durationFraction);
    for(var d = 0;d < b.length;d++) {
      var e = b[d];
      e.eventName == "onstatechange" && e.handler(this, a, this.getState(), this.durationFraction, this.timelinePosition)
    }
    for(d = 0;d < c.length;d++) {
      c[d].updateValue(this.timelinePosition)
    }
  }
}
function TimelineScenario() {
  this.waitingActors = [];
  this.runningActors = [];
  this.doneActors = [];
  var a = [];
  this.dependencies = {};
  this.statePriorToSuspension = this.state = void 0;
  this.isLooping = !1;
  this.id = timelineScenarioId++;
  var b = [];
  this.__checkDependencyParam = function(a) {
    if(this.waitingActors.indexOf(a) == -1) {
      throw"Must be first added with addScenarioActor() API";
    }
  };
  this.__checkDoneActors = function() {
    for(var a = this.runningActors.length - 1;a >= 0;a--) {
      var b = this.runningActors[a];
      b.isDone() && (this.doneActors[this.doneActors.length] = b, this.runningActors.splice(a, 1))
    }
  };
  this.getReadyActors = function() {
    if(this.state == TimelineScenarioState.SUSPENDED) {
      return[]
    }
    this.__checkDoneActors();
    for(var b = [], d = this.waitingActors.length - 1;d >= 0;d--) {
      var f = this.waitingActors[d], g = !0, h = this.dependencies[a.indexOf(f)];
      if(h != void 0) {
        for(var e = 0;e < h.length;e++) {
          if(this.doneActors.indexOf(h[e]) == -1) {
            g = !1;
            break
          }
        }
      }
      g && (this.runningActors[this.runningActors.length] = f, this.waitingActors.splice(d, 1), b[b.length] = f)
    }
    if(this.waitingActors.length == 0 && this.runningActors.length == 0) {
      if(this.isLooping) {
        for(d = 0;d < this.doneActors.length;d++) {
          f = this.doneActors[d], f.resetDoneFlag(), this.waitingActors[this.waitingActors.length] = f
        }
        this.doneActors.length = 0
      }else {
        this.state = TimelineScenarioState.DONE
      }
    }
    return b
  };
  this.cancel = function() {
    if(this.state == TimelineScenarioState.PLAYING) {
      this.state = TimelineScenarioState.DONE;
      for(var a = 0;a < this.waitingActors.length;a++) {
        var b = this.waitingActors[a];
        b instanceof Timeline && b.cancel()
      }
      for(a = 0;a < this.runningActors.length;a++) {
        b = this.runningActors[a], b instanceof Timeline && b.cancel()
      }
    }
  };
  this.suspend = function() {
    var a = this.state;
    if(a == TimelineScenarioState.PLAYING) {
      this.statePriorToSuspension = a;
      this.state = TimelineScenarioState.SUSPENDED;
      for(a = 0;a < this.runningActors.length;a++) {
        var b = this.runningActors[a];
        b instanceof Timeline && b.suspend()
      }
    }
  };
  this.resume = function() {
    if(this.state == TimelineScenarioState.SUSPENDED) {
      this.state = this.statePriorToSuspension;
      for(var a = 0;a < this.runningActors.length;a++) {
        var b = this.runningActors[a];
        b instanceof Timeline && b.resume()
      }
    }
  };
  this.__playScenario = function() {
    runningScenarios[this.id] = this;
    for(var a = this.getReadyActors(), b = 0;b < a.length;b++) {
      a[b].play()
    }
  };
  this.__callbackCallTimelineScenarioEnded = function() {
    for(var a = 0;a < b.length;a++) {
      var d = b[a];
      d.eventName == "ondone" && d.handler(this)
    }
  };
  this.addEventListener = function(a, d) {
    var f = new EventHandler(a, d);
    b[b.length] = f
  };
  this.addScenarioActor = function(b) {
    if(b.isDone()) {
      throw"Already finished";
    }
    this.waitingActors[this.waitingActors.length] = b;
    a[a.length] = b
  };
  this.addDependency = function(b, d) {
    this.__checkDependencyParam(b);
    for(var f = 0;f < d.length;f++) {
      var g = d[f];
      this.__checkDependencyParam(g)
    }
    f = a.indexOf(b);
    this.dependencies[f] == void 0 && (this.dependencies[f] = []);
    for(var h = this.dependencies[f], f = 0;f < d.length;f++) {
      g = d[f], h[h.length] = g
    }
  };
  this.play = function() {
    this.isLooping = !1;
    this.state = TimelineScenarioState.PLAYING;
    this.__playScenario()
  };
  this.playLoop = function() {
    for(var a = 0;a < this.waitingActors.length;a++) {
      if(!this.waitingActors[a].supportsReplay()) {
        throw"Can't loop scenario with actor(s) that don't support replay";
      }
    }
    this.isLooping = !0;
    this.state = TimelineScenarioState.PLAYING;
    this.__playScenario()
  }
}
var runningTimelines = {}, runningScenarios = {}, timerCallbackId = setInterval("globalTimerCallback()", 40);
setPulseRate = function() {
  clearInterval(timerCallbackId);
  timerCallbackId = setInterval("globalTimerCallback()", 20)
};
globalTimerCallback = function() {
  var a = (new Date).getTime(), b = a - lastTime, c = 0, d = 0, f = 0, g = 0, h;
  for(h in runningTimelines) {
    d++;
    var e = runningTimelines[h], j = e.getState();
    if(e.getState() != TimelineState.SUSPENDED) {
      var i = !1;
      if(e.getState() == TimelineState.READY) {
        if(e.timeUntilPlay - b > 0) {
          e.timeUntilPlay -= b;
          continue
        }
        i = !0;
        e.__popState();
        e.__callbackCallTimelineStateChanged(TimelineState.READY)
      }
      var l = !1;
      if(j == TimelineState.PLAYING_FORWARD) {
        i || (e.durationFraction += b / e.duration);
        if(e.durationFraction > 1) {
          if(e.durationFraction = 1, e.timelinePosition = 1, e.isLooping) {
            var k = e.toCancelAtCycleBreak, m = e.repeatCount;
            if(m > 0) {
              m--, k = k || m == 0, e.repeatCount = m
            }
            if(k) {
              l = !0
            }else {
              e.repeatBehavior == RepeatBehavior.REVERSE ? e.__replaceState(TimelineState.PLAYING_REVERSE) : (e.durationFraction = 0, e.timelinePosition = 0);
              if(e.cycleDelay > 0) {
                e.__pushState(TimelineState.READY), e.timeUntilPlay = e.cycleDelay
              }
              e.__callbackCallTimelineStateChanged(TimelineState.PLAYING_FORWARD)
            }
          }else {
            l = !0
          }
        }
        e.__callbackCallTimelinePulse()
      }
      if(j == TimelineState.PLAYING_REVERSE) {
        i || (e.durationFraction -= b / e.duration);
        if(e.durationFraction < 0) {
          if(e.durationFraction = 0, e.timelinePosition = 0, e.isLooping) {
            k = e.toCancelAtCycleBreak;
            m = e.repeatCount;
            if(m > 0) {
              m--, k = k || m == 0, e.repeatCount = m
            }
            if(k) {
              l = !0
            }else {
              e.__replaceState(TimelineState.PLAYING_FORWARD);
              if(e.cycleDelay > 0) {
                e.__pushState(TimelineState.READY), e.timeUntilPlay = e.cycleDelay
              }
              e.__callbackCallTimelineStateChanged(TimelineState.PLAYING_REVERSE)
            }
          }else {
            l = !0
          }
        }
        e.__callbackCallTimelinePulse()
      }
      l ? (j = e.getState(), e.__replaceState(TimelineState.DONE), e.__callbackCallTimelineStateChanged(j), e.__popState(), e.__callbackCallTimelineStateChanged(TimelineState.DONE), delete runningTimelines[h]) : c++
    }
  }
  for(var n in runningScenarios) {
    if(g++, b = runningScenarios[n], b.state == TimelineScenarioState.DONE) {
      delete runningScenarios[n], b.__callbackCallTimelineScenarioEnded()
    }else {
      if(f++, b = b.getReadyActors(), b.length > 0) {
        for(c = 0;c < b.length;c++) {
          b[c].play()
        }
      }
    }
  }
  lastTime = a
};

